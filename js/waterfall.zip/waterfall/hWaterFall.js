let lastImageHeight;

$(document).ready(function () {
    insertImg();
    $(document).scroll(function () {
        checkFlag();
    });
})

function checkFlag() {
    let pageHeight = document.documentElement.clientHeight || document.body.clientHeight;
    let scrollHeight = document.documentElement.scrollTop || document.body.scrollTop;
    console.log(lastImageHeight,pageHeight ,scrollHeight)
    if(lastImageHeight < pageHeight + scrollHeight){
        insertImg();
    }
}

function insertImg() {
    // let box = $("<div></div>");
    // box.addClass('hWaterfall');
    // $("#container").append(box);
    //
    // let image = $("<img>")
    // image.attr("src","images/"+Math.floor(Math.random()*10)+".jpg");
    //
    // image.load(function () {
    //     box.append(image);
    //     lastImageHeight = box.offset().top;
    //     console.log(image.width(),image.height(),lastImageHeight,document.body.clientHeight);
    //     if(lastImageHeight < document.body.clientHeight){
    //         insertImg()
    //     }
    // })




    let box = document.createElement('div');
    box.className = 'hWaterfall';
    $("#container").append(box);

    let image = document.createElement('img');
    image.setAttribute("src","images/"+Math.floor(Math.random()*97)+".jpg");
    box.append(image);

    lastImageHeight = image.offsetTop;
    console.log("width:"+image.width,"height:"+image.height);
    if(image.offsetTop < document.body.clientHeight){
        insertImg()
    }


}
